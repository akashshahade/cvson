
from flask import Flask, jsonify, request
import numpy as np
import io
import base64
import matplotlib
matplotlib.use('Agg') # Non-interactive backend
import matplotlib.pyplot as plt
from skimage.morphology import skeletonize
from scipy.ndimage import distance_transform_edt, binary_dilation
from sklearn.decomposition import PCA

app = Flask(__name__)

def fig_to_base64(fig):
    img = io.BytesIO()
    fig.savefig(img, format='png', bbox_inches='tight', dpi=100)
    img.seek(0)
    return base64.b64encode(img.getvalue()).decode('utf-8')

@app.route('/api/chart/crack', methods=['GET'])
def get_crack_chart():
    # Case B simulation (iter=3)
    thickness_iter = 3
    image = np.zeros((300, 300), dtype=np.uint8)
    # Simple jagged path
    pts = [(50, 100), (80, 115), (120, 105), (160, 130), (210, 110), (250, 140)]
    from skimage.draw import line
    for i in range(len(pts)-1):
        rr, cc = line(pts[i][0], pts[i][1], pts[i+1][0], pts[i+1][1])
        image[rr, cc] = 1
    
    mask = binary_dilation(image, iterations=thickness_iter).astype(np.uint8)
    skel = skeletonize(mask)
    
    # Calculate metrics
    edt_map = distance_transform_edt(mask)
    width = float(np.max(edt_map) * 2)
    length = float(np.sum(skel))

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(8, 4))
    ax1.imshow(mask, cmap='gray')
    ax1.set_title("Binary Mask")
    ax1.axis('off')
    ax2.imshow(skel, cmap='inferno')
    ax2.set_title("Skeleton")
    ax2.axis('off')
    
    img_b64 = fig_to_base64(fig)
    plt.close(fig)
    
    return jsonify({
        "image": img_b64,
        "metrics": {"width": width, "length": length}
    })

@app.route('/api/chart/porosity', methods=['GET'])
def get_porosity_chart():
    # Case B (radius=20)
    grid_size = 200
    radius = 20
    y, x = np.ogrid[:grid_size, :grid_size]
    mask = np.sqrt((x - 100)**2 + (y - 100)**2) <= radius
    
    pvf = (np.sum(mask) / (grid_size**2)) * 100
    diameter = radius * 2

    fig, ax = plt.subplots(figsize=(4, 4))
    ax.imshow(mask, cmap='magma')
    ax.axis('off')
    
    img_b64 = fig_to_base64(fig)
    plt.close(fig)
    
    return jsonify({
        "image": img_b64,
        "metrics": {"pvf": pvf, "diameter": diameter}
    })

@app.route('/api/chart/tilt', methods=['GET'])
def get_tilt_chart():
    # Since matplotlib 3D is hard to interact with via static images, 
    # we return raw points and vectors for Plotly to render in the frontend.
    height, radius, n_points = 200, 20, 2000
    theta = np.random.uniform(0, 2*np.pi, n_points)
    z = np.random.uniform(0, height, n_points)
    x = radius * np.cos(theta)
    y = radius * np.sin(theta)
    points = np.column_stack((x, y, z))
    
    # Rotate 2 degrees around Y
    angle = np.radians(2.0)
    rot = np.array([[np.cos(angle), 0, np.sin(angle)], [0, 1, 0], [-np.sin(angle), 0, np.cos(angle)]])
    rotated = points @ rot.T
    
    pca = PCA(n_components=3).fit(rotated)
    vector = pca.components_[0].tolist()
    centroid = np.mean(rotated, axis=0).tolist()
    
    return jsonify({
        "points": rotated.tolist(),
        "vector": vector,
        "centroid": centroid,
        "tilt": 2.0
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)
