
import React from 'react';
import { Upload, FileImage, Play, X, ImageIcon } from 'lucide-react';

interface Props {
  onUpload: (type: 'xray' | 'ct', file: File | null) => void;
  files: { xray: File | null; ct: File | null };
  onStartAnalysis: () => void;
}

const ImageUpload: React.FC<Props> = ({ onUpload, files, onStartAnalysis }) => {
  const isReady = files.xray && files.ct;

  const handleFileChange = (type: 'xray' | 'ct', e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    onUpload(type, file);
  };

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <UploadZone 
          title="X-ray Scan" 
          file={files.xray} 
          onFileChange={(e) => handleFileChange('xray', e)}
          onClear={() => onUpload('xray', null)}
          description="Planar radiography (PNG/JPG)"
        />
        <UploadZone 
          title="CT Volumetric Scan" 
          file={files.ct} 
          onFileChange={(e) => handleFileChange('ct', e)}
          onClear={() => onUpload('ct', null)}
          description="3D slice sequence (TIFF/DICOM)"
        />
      </div>

      <div className="flex justify-center pt-8">
        <button
          onClick={onStartAnalysis}
          disabled={!isReady}
          className={`
            flex items-center gap-3 px-12 py-5 rounded-2xl font-bold text-xl shadow-xl transition-all
            ${isReady 
              ? 'bg-brand text-white hover:scale-105 active:scale-95 shadow-brand/20' 
              : 'bg-gray-200 text-gray-400 cursor-not-allowed dark:bg-gray-800'}
          `}
        >
          <Play fill="currentColor" size={24} />
          Start Analysis
        </button>
      </div>
      {!isReady && (
        <p className="text-center text-sm text-gray-400">Please upload both scans to proceed.</p>
      )}
    </div>
  );
};

const UploadZone = ({ title, file, onFileChange, onClear, description }: any) => {
  const inputId = `file-${title.replace(/\s+/g, '-').toLowerCase()}`;
  
  return (
    <div className={`relative flex flex-col items-center justify-center p-8 border-2 border-dashed rounded-3xl transition-all h-[300px] ${
      file ? 'border-brand bg-brand/5' : 'border-gray-200 dark:border-gray-800 hover:border-brand/50 bg-white dark:bg-dark-lighter'
    }`}>
      {file ? (
        <div className="text-center space-y-4">
          <div className="w-20 h-20 bg-brand/10 text-brand rounded-2xl flex items-center justify-center mx-auto">
            <ImageIcon size={40} />
          </div>
          <div className="space-y-1">
            <p className="font-bold truncate max-w-[200px]">{file.name}</p>
            <p className="text-xs text-gray-500">{(file.size / (1024 * 1024)).toFixed(2)} MB</p>
          </div>
          <button 
            onClick={onClear}
            className="absolute top-4 right-4 p-2 bg-red-100 text-red-600 rounded-full hover:bg-red-200 transition-colors"
          >
            <X size={16} />
          </button>
        </div>
      ) : (
        <label htmlFor={inputId} className="cursor-pointer text-center group">
          <input 
            id={inputId}
            type="file" 
            className="hidden" 
            accept="image/*"
            onChange={onFileChange}
          />
          <div className="mb-4 w-16 h-16 bg-gray-100 dark:bg-gray-800 text-gray-400 group-hover:text-brand group-hover:bg-brand/10 rounded-2xl flex items-center justify-center mx-auto transition-all">
            <Upload size={32} />
          </div>
          <p className="text-lg font-bold mb-1">{title}</p>
          <p className="text-sm text-gray-400">{description}</p>
        </label>
      )}
    </div>
  );
};

export default ImageUpload;
