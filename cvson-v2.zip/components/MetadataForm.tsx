
import React, { useState } from 'react';
import { SpoutMetadata } from '../types';

interface Props {
  initialData: SpoutMetadata;
  onSubmit: (data: SpoutMetadata, isDemo?: boolean) => void;
}

const MetadataForm: React.FC<Props> = ({ initialData, onSubmit }) => {
  const [data, setData] = useState(initialData);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(data, false);
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white dark:bg-dark-lighter p-8 rounded-2xl border dark:border-gray-800 shadow-sm space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <label className="text-sm font-semibold text-gray-600 dark:text-gray-400">Spout Serial No.</label>
          <input 
            type="text" 
            required
            value={data.serialNo}
            onChange={(e) => setData({...data, serialNo: e.target.value})}
            placeholder="e.g. SP-2026-A102"
            className="w-full px-4 py-3 rounded-xl border dark:bg-gray-800 dark:border-gray-700 focus:ring-2 focus:ring-brand focus:border-transparent outline-none transition-all dark:text-white"
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-semibold text-gray-600 dark:text-gray-400">Batch ID</label>
          <input 
            type="text" 
            required
            value={data.batchId}
            onChange={(e) => setData({...data, batchId: e.target.value})}
            placeholder="e.g. BATCH-Q1-FEB"
            className="w-full px-4 py-3 rounded-xl border dark:bg-gray-800 dark:border-gray-700 focus:ring-2 focus:ring-brand focus:border-transparent outline-none transition-all dark:text-white"
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-semibold text-gray-600 dark:text-gray-400">Operator Name</label>
          <input 
            type="text" 
            required
            value={data.operator}
            onChange={(e) => setData({...data, operator: e.target.value})}
            placeholder="Full Name"
            className="w-full px-4 py-3 rounded-xl border dark:bg-gray-800 dark:border-gray-700 focus:ring-2 focus:ring-brand focus:border-transparent outline-none transition-all dark:text-white"
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-semibold text-gray-600 dark:text-gray-400">Scan Date</label>
          <input 
            type="date" 
            required
            value={data.scanDate}
            onChange={(e) => setData({...data, scanDate: e.target.value})}
            className="w-full px-4 py-3 rounded-xl border dark:bg-gray-800 dark:border-gray-700 focus:ring-2 focus:ring-brand focus:border-transparent outline-none transition-all dark:text-white"
          />
        </div>
      </div>
      
      <div className="pt-4">
        <button 
          type="submit"
          className="w-full bg-brand text-white py-4 rounded-xl font-bold text-lg hover:bg-blue-600 shadow-lg shadow-blue-500/20 active:scale-[0.98] transition-all"
        >
          Proceed to Upload
        </button>
        <button 
          type="button"
          onClick={() => onSubmit({
            serialNo: 'S-9042-DEMO',
            batchId: 'BATCH-2026-X',
            operator: 'Demo System',
            scanDate: new Date().toISOString().split('T')[0]
          }, true)}
          className="w-full mt-4 text-brand font-semibold py-2 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-xl transition-colors"
        >
          Try with Sample Data
        </button>
      </div>
    </form>
  );
};

export default MetadataForm;
