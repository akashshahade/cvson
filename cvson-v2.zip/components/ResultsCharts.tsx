
import React, { useState, useEffect, useRef, useImperativeHandle, forwardRef } from 'react';
import { Download } from 'lucide-react';

interface ResultsChartsProps {}

export interface ResultsChartsRef {
  captureCharts: () => Promise<{ [key: string]: string }>;
}

const ResultsCharts = forwardRef<ResultsChartsRef, ResultsChartsProps>((props, ref) => {
  const [loading, setLoading] = useState(true);
  const crackRef = useRef<HTMLDivElement>(null);
  const porosityRef = useRef<HTMLDivElement>(null);
  const tiltRef = useRef<HTMLDivElement>(null);

  useImperativeHandle(ref, () => ({
    captureCharts: async () => {
      const Plotly = (window as any).Plotly;
      if (!Plotly) return {};
      
      const images: { [key: string]: string } = {};
      try {
        if (crackRef.current) images.crack = await Plotly.toImage(crackRef.current, { format: 'png', height: 400, width: 800 });
        if (porosityRef.current) images.porosity = await Plotly.toImage(porosityRef.current, { format: 'png', height: 400, width: 800 });
        if (tiltRef.current) images.tilt = await Plotly.toImage(tiltRef.current, { format: 'png', height: 400, width: 800 });
      } catch (err) {
        console.error("Failed to capture Plotly charts", err);
      }
      return images;
    }
  }));

  useEffect(() => {
    const simulateData = async () => {
      setLoading(true);
      await new Promise(r => setTimeout(r, 1200));
      setLoading(false);
    };
    simulateData();
  }, []);

  useEffect(() => {
    if (!loading && (window as any).Plotly) {
      renderCrackChart();
      renderPorosityChart();
      renderTiltChart();
    }
  }, [loading]);

  const renderCrackChart = () => {
    const x = [100, 140, 170, 160, 190, 220, 210, 230];
    const y = [50, 80, 110, 140, 180, 220, 250, 280];
    
    const trace1 = {
      x, y,
      xaxis: 'x',
      yaxis: 'y',
      mode: 'lines',
      name: 'Binary Mask',
      line: { color: '#ffffff', width: 6 },
    };

    const trace2 = {
      x, y,
      xaxis: 'x2',
      yaxis: 'y2',
      mode: 'lines',
      name: 'Skeleton',
      line: { color: '#ffffaa', width: 1.5 },
    };

    const layout = {
      grid: { rows: 2, columns: 1, pattern: 'independent', roworder: 'top to bottom' },
      margin: { l: 50, r: 20, b: 50, t: 40 },
      paper_bgcolor: 'black',
      plot_bgcolor: 'black',
      showlegend: false,
      xaxis: { title: 'X-Pos (px)', gridcolor: '#333', color: '#999', domain: [0, 1], anchor: 'y' },
      yaxis: { title: 'Y-Pos (px)', gridcolor: '#333', color: '#999', domain: [0.55, 1], anchor: 'x' },
      xaxis2: { title: 'X-Pos (px)', gridcolor: '#333', color: '#999', domain: [0, 1], anchor: 'y2' },
      yaxis2: { title: 'Y-Pos (px)', gridcolor: '#333', color: '#999', domain: [0, 0.45], anchor: 'x2' },
      title: { text: 'Case A Analysis (Calculated)', font: { color: '#fff', size: 10 }, y: 0.98 }
    };

    (window as any).Plotly.newPlot(crackRef.current, [trace1, trace2], layout, { responsive: true, displayModeBar: false });
  };

  const renderPorosityChart = () => {
    const grid_size = 200;
    const radius = 15;
    const z = Array.from({ length: grid_size }, (_, i) => 
      Array.from({ length: grid_size }, (_, j) => {
        const d = Math.sqrt((i - 100)**2 + (j - 100)**2);
        return d <= radius ? 1 : 0;
      })
    );

    const trace1 = {
      z: z,
      type: 'heatmap',
      colorscale: [
        [0, 'black'],
        [1, '#ffffcc']
      ],
      showscale: false,
    };

    const layout = {
      margin: { l: 50, r: 20, b: 50, t: 30 },
      paper_bgcolor: 'black',
      plot_bgcolor: 'black',
      xaxis: { title: 'U-Axis (voxel)', gridcolor: '#333', color: '#999', zeroline: false },
      yaxis: { title: 'V-Axis (voxel)', gridcolor: '#333', color: '#999', zeroline: false },
      title: { text: 'Porosity Void Mask (r=15)', font: { color: '#fff', size: 10 } }
    };

    (window as any).Plotly.newPlot(porosityRef.current, [trace1], layout, { responsive: true, displayModeBar: false });
  };

  const renderTiltChart = () => {
    const n = 1200;
    const x = [], y = [], z = [];
    const angle = 2.5 * Math.PI / 180; // 2.5 degree tilt
    
    for(let i=0; i<n; i++) {
      const h = Math.random() * 200;
      const r = 18;
      const t = Math.random() * 2 * Math.PI;
      const px = r * Math.cos(t);
      const py = r * Math.sin(t);
      const pz = h;
      x.push(px * Math.cos(angle) + pz * Math.sin(angle));
      y.push(py);
      z.push(-px * Math.sin(angle) + pz * Math.cos(angle));
    }

    const trace1 = {
      x, y, z,
      mode: 'markers',
      marker: { size: 1.5, color: z, colorscale: 'Viridis', opacity: 0.5 },
      type: 'scatter3d',
      name: 'Voxel Cloud'
    };

    // Detected PCA Axis (Tilted Blue)
    const trace2 = {
      x: [-40 * Math.sin(angle), 40 * Math.sin(angle)],
      y: [0, 0],
      z: [-10, 210],
      mode: 'lines',
      line: { color: '#007AC2', width: 6 },
      type: 'scatter3d',
      name: 'Detected Axis'
    };

    // Design Axis (Straight Red)
    const trace3 = {
      x: [0, 0],
      y: [0, 0],
      z: [-10, 210],
      mode: 'lines',
      line: { color: '#ef4444', width: 4, dash: 'solid' },
      type: 'scatter3d',
      name: 'Design Axis'
    };

    const layout = {
      margin: { l: 0, r: 0, b: 0, t: 0 },
      paper_bgcolor: 'rgba(0,0,0,0)',
      plot_bgcolor: 'rgba(0,0,0,0)',
      scene: {
        xaxis: { title: 'X (mm)', visible: true, color: '#999', gridcolor: '#333' },
        yaxis: { title: 'Y (mm)', visible: true, color: '#999', gridcolor: '#333' },
        zaxis: { title: 'Z (mm)', visible: true, color: '#999', gridcolor: '#333' },
        aspectmode: 'cube'
      },
      showlegend: false
    };

    (window as any).Plotly.newPlot(tiltRef.current, [trace1, trace2, trace3], layout, { responsive: true, displayModeBar: false });
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
      {loading ? (
        [1, 2, 3].map(i => (
          <div key={i} className="bg-white dark:bg-dark-card p-6 rounded-2xl shadow-sm border dark:border-gray-800 animate-pulse h-[450px]">
            <div className="h-6 w-3/4 bg-gray-200 dark:bg-gray-700 rounded mb-4" />
            <div className="flex-1 bg-gray-100 dark:bg-gray-800 rounded-xl mb-4 h-64" />
          </div>
        ))
      ) : (
        <>
          <InteractiveCard 
            title="Crack Analysis — X-Ray" 
            containerRef={crackRef}
            height="h-[400px]"
            labels={[
              { label: "Max Crack Width", value: "4.0 px" },
              { label: "Crack Length", value: "214 px" }
            ]}
          />
          <InteractiveCard 
            title="Porosity Analysis — CT Scan" 
            containerRef={porosityRef}
            height="h-[400px]"
            labels={[
              { label: "PVF", value: "0.50%" },
              { label: "Max Pore Dia", value: "30 px" }
            ]}
          />
          <InteractiveCard 
            title="Mesh Axis Tilt — CT Cloud" 
            containerRef={tiltRef}
            height="h-[400px]"
            labels={[
              { label: "Detected Tilt", value: "2.5°" },
              { label: "Reference Axis", value: "Design Ideal" }
            ]}
          />
        </>
      )}
    </div>
  );
});

const InteractiveCard = ({ title, containerRef, labels, height = "h-56" }: any) => (
  <div className="bg-white dark:bg-dark-card p-6 rounded-2xl shadow-sm border dark:border-gray-800 flex flex-col h-full group">
    <div className="flex justify-between items-start mb-4">
      <h4 className="font-bold text-lg dark:text-white leading-tight">{title}</h4>
      <button className="p-2 text-gray-400 hover:text-brand transition-colors"><Download size={18} /></button>
    </div>
    <div ref={containerRef} className={`${height} w-full rounded-xl overflow-hidden bg-black`} />
    <div className="mt-4 flex flex-wrap gap-2">
      {labels.map((l: any, i: number) => (
        <span key={i} className={`px-3 py-1 rounded-full text-[10px] font-bold shadow-sm ${
          l.label.includes('Reference') ? 'bg-red-500 text-white' : 'bg-brand text-white'
        }`}>
          {l.label}: {l.value}
        </span>
      ))}
    </div>
  </div>
);

export default ResultsCharts;
