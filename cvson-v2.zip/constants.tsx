
import { PipelineStep, Severity, Metric } from './types';

export const PIPELINE_STEPS: PipelineStep[] = [
  { id: 1, label: 'Image Ingestion', method: 'File Upload', status: 'pending' },
  { id: 2, label: 'Crack Segmentation', method: 'Attention U-Net', status: 'pending' },
  { id: 3, label: '3D Volume Segmentation', method: 'V-Net', status: 'pending' },
  { id: 4, label: 'Crack Thinning', method: 'Zhang-Suen Algorithm', status: 'pending' },
  { id: 5, label: 'Crack Geometry', method: 'Connected Components', status: 'pending' },
  { id: 6, label: 'Porosity Calculation', method: 'CT Voxel Counting', status: 'pending' },
  { id: 7, label: 'Point Cloud & PCA', method: 'Principal Component Analysis', status: 'pending' },
  { id: 8, label: 'Mesh Tilt', method: 'Axis Alignment', status: 'pending' },
  { id: 9, label: 'Rule Validation', method: 'Threshold Analysis', status: 'pending' },
  { id: 10, label: 'Final Verdict', method: 'Decision Engine', status: 'pending' },
];

export const generateRandomMetrics = (): Metric[] => {
  // Randomly decide between 3 scenarios (2 Pass, 1 Fail)
  const scenario = Math.floor(Math.random() * 3);
  const isPass = scenario < 2; // 0, 1 are Pass; 2 is Fail
  
  // Scenario 0: Perfect Pass (0.5% porosity)
  // Scenario 1: Marginal Pass (1.5% - 2.0% porosity)
  // Scenario 2: Fail (2.25%+ porosity or long crack)

  let crackLength: number;
  let porosity: number;

  if (scenario === 0) {
    crackLength = 0.8 + Math.random() * 0.4;
    porosity = 0.5;
  } else if (scenario === 1) {
    crackLength = 1.4 + Math.random() * 0.5;
    porosity = 1.5 + Math.random() * 0.5;
  } else {
    // Fail case
    const failReason = Math.random() > 0.5;
    crackLength = failReason ? 2.15 + Math.random() * 0.4 : 1.2;
    porosity = failReason ? 1.4 : 2.25;
  }

  const confidence = 88 + Math.random() * 8;

  return [
    { 
      parameter: 'Max Crack Length', 
      measured: `${crackLength.toFixed(2)} mm`, 
      threshold: '< 2.0 mm', 
      status: crackLength < 2.0 ? 'PASS' : 'FAIL', 
      severity: crackLength < 1.6 ? Severity.OK : (crackLength < 2.0 ? Severity.WARNING : Severity.CRITICAL),
      value: crackLength 
    },
    { 
      parameter: 'Max Crack Width', 
      measured: '0.21 mm', 
      threshold: '< 0.25 mm', 
      status: 'PASS', 
      severity: Severity.OK, 
      value: 0.21 
    },
    { 
      parameter: 'Porosity Volume Fraction', 
      measured: `${porosity.toFixed(2)} %`, 
      threshold: '< 2.0 %', 
      status: porosity <= 2.0 ? 'PASS' : 'FAIL', 
      severity: porosity < 1.0 ? Severity.OK : (porosity <= 2.0 ? Severity.WARNING : Severity.CRITICAL),
      value: porosity 
    },
    { 
      parameter: 'Max Pore Diameter', 
      measured: '0.38 mm', 
      threshold: '< 0.50 mm', 
      status: 'PASS', 
      severity: Severity.OK, 
      value: 0.38 
    },
    { 
      parameter: 'Mesh Axis Tilt', 
      measured: '1.9°', 
      threshold: '< 3.0°', 
      status: 'PASS', 
      severity: Severity.OK, 
      value: 1.9 
    },
    { 
      parameter: 'Confidence Score', 
      measured: `${confidence.toFixed(1)} %`, 
      threshold: '> 80 %', 
      status: 'PASS', 
      severity: Severity.OK, 
      value: confidence 
    },
  ];
};

export const MOCK_METRICS: Metric[] = generateRandomMetrics();

export const HISTORY_ITEMS = [
  { id: 'S-9021', date: '2026-02-14', verdict: 'PASS' },
  { id: 'S-9018', date: '2026-02-12', verdict: 'FAIL' },
  { id: 'S-9015', date: '2026-02-10', verdict: 'PASS' },
];
