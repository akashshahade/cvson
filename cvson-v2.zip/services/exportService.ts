
import { SpoutMetadata, Metric } from '../types';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';

/**
 * Service to handle PDF and Excel exports with embedded images.
 */

export const exportToPDF = (metadata: SpoutMetadata, metrics: Metric[], chartImages: { [key: string]: string } = {}) => {
  try {
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });
    
    const timestamp = new Date().toLocaleString();
    const pageWidth = doc.internal.pageSize.getWidth();
    
    // Header background
    doc.setFillColor(0, 122, 194); // Eaton Blue (#007AC2)
    doc.rect(0, 0, pageWidth, 45, 'F');
    
    // Title
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(22);
    doc.text('SpoutAI Inspection Report', 15, 25);
    
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text(`Generated: ${timestamp}`, 15, 35);
    doc.text(`System Version: 1.0 MVP`, 15, 40);

    // Metadata Section
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Inspection Metadata', 15, 60);
    
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text(`Serial Number: ${metadata.serialNo}`, 15, 70);
    doc.text(`Batch ID: ${metadata.batchId}`, 15, 76);
    doc.text(`Lead Operator: ${metadata.operator}`, 15, 82);
    doc.text(`Scan Date: ${metadata.scanDate}`, 15, 88);

    // Embed Interactive Charts
    let yOffset = 100;
    if (Object.keys(chartImages).length > 0) {
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(12);
      doc.text('Visual Analysis Results', 15, yOffset);
      yOffset += 5;

      // Add Crack Analysis
      if (chartImages.crack && typeof chartImages.crack === 'string' && chartImages.crack.startsWith('data:')) {
        doc.addImage(chartImages.crack, 'PNG', 15, yOffset, 85, 45, undefined, 'FAST');
      }
      
      // Add Porosity
      if (chartImages.porosity && typeof chartImages.porosity === 'string' && chartImages.porosity.startsWith('data:')) {
        doc.addImage(chartImages.porosity, 'PNG', 110, yOffset, 85, 45, undefined, 'FAST');
      }
      yOffset += 55;

      // Add Tilt
      if (chartImages.tilt && typeof chartImages.tilt === 'string' && chartImages.tilt.startsWith('data:')) {
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(10);
        doc.text('Mesh Axis Tilt (3D PCA Analysis)', 15, yOffset);
        yOffset += 5;
        doc.addImage(chartImages.tilt, 'PNG', 15, yOffset, 180, 80, undefined, 'FAST');
        yOffset += 90;
      }
    }

    // Check if we need a new page for the metrics table
    if (yOffset > 190) {
      doc.addPage();
      yOffset = 20;
    } else {
      yOffset += 5;
    }

    // Metrics Table
    autoTable(doc, {
      startY: yOffset,
      head: [['Parameter', 'Measured', 'Requirement', 'Status', 'Severity']],
      body: metrics.map(m => [
        m.parameter, 
        m.measured, 
        m.threshold, 
        m.status,
        m.severity
      ]),
      theme: 'striped',
      headStyles: { 
        fillColor: [0, 122, 194], 
        textColor: [255, 255, 255],
        fontStyle: 'bold',
        fontSize: 9
      },
      styles: { fontSize: 8 },
      columnStyles: {
        3: { fontStyle: 'bold' } // Status column
      },
      didParseCell: (data) => {
        if (data.section === 'body' && data.column.index === 3) {
          if (data.cell.raw === 'FAIL') {
            data.cell.styles.textColor = [220, 38, 38]; // Red
          } else {
            data.cell.styles.textColor = [22, 163, 74]; // Green
          }
        }
      }
    });

    const finalY = (doc as any).lastAutoTable.finalY || yOffset + 50;
    const isPass = metrics.every(m => m.status === 'PASS');
    const footerY = Math.min(finalY + 15, 260);
    
    // Final Verdict Box
    doc.setFillColor(isPass ? 240 : 254, isPass ? 253 : 242, isPass ? 244 : 242);
    doc.rect(15, footerY, 180, 15, 'F');
    
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(isPass ? [22, 163, 74] : [220, 38, 38]);
    doc.text(`QUALITY DECISION: ${isPass ? 'APPROVED (PASS)' : 'REJECTED (FAIL)'}`, pageWidth / 2, footerY + 9.5, { align: 'center' });
    
    // Footer
    doc.setFontSize(7);
    doc.setTextColor(150, 150, 150);
    doc.text('CONFIDENTIAL - EATON SpoutAI Internal QC Automated Report', pageWidth / 2, 285, { align: 'center' });

    doc.save(`SpoutAI_Report_${metadata.serialNo}_${Date.now()}.pdf`);
  } catch (error) {
    console.error("PDF Export failed", error);
    alert("Could not generate PDF. Please ensure all charts are loaded and try again.");
  }
};

export const exportToExcel = (metadata: SpoutMetadata, metrics: Metric[]) => {
  try {
    const metaData = [
      { Category: 'Serial Number', Value: metadata.serialNo },
      { Category: 'Batch ID', Value: metadata.batchId },
      { Category: 'Operator', Value: metadata.operator },
      { Category: 'Date', Value: metadata.scanDate },
      { Category: 'Overall Result', Value: metrics.every(m => m.status === 'PASS') ? 'PASS' : 'FAIL' },
      { Category: 'Generated At', Value: new Date().toLocaleString() }
    ];

    const resultsData = metrics.map(m => ({
      'Inspection Parameter': m.parameter,
      'Measured Value': m.measured,
      'Requirement': m.threshold,
      'Status': m.status,
      'Severity': m.severity
    }));

    const wb = XLSX.utils.book_new();
    const ws1 = XLSX.utils.json_to_sheet(metaData);
    const ws2 = XLSX.utils.json_to_sheet(resultsData);

    // Auto-width for columns
    const wscols1 = [{ wch: 25 }, { wch: 35 }];
    const wscols2 = [{ wch: 30 }, { wch: 20 }, { wch: 20 }, { wch: 15 }, { wch: 15 }];
    ws1['!cols'] = wscols1;
    ws2['!cols'] = wscols2;

    XLSX.utils.book_append_sheet(wb, ws1, "Metadata");
    XLSX.utils.book_append_sheet(wb, ws2, "Analysis Metrics");

    XLSX.writeFile(wb, `SpoutAI_Data_${metadata.serialNo}.xlsx`);
  } catch (error) {
    console.error("Excel Export failed", error);
    alert("Could not generate Excel file.");
  }
};
