
export interface SpoutMetadata {
  serialNo: string;
  batchId: string;
  operator: string;
  scanDate: string;
}

export enum Severity {
  OK = 'OK',
  WARNING = 'WARNING',
  CRITICAL = 'CRITICAL'
}

export interface Metric {
  parameter: string;
  measured: string;
  threshold: string;
  status: 'PASS' | 'FAIL';
  severity: Severity;
  value: number;
}

export interface AnalysisResult {
  verdict: 'PASS' | 'FAIL';
  confidence: number;
  reason: string;
  metrics: Metric[];
}

export interface PipelineStep {
  id: number;
  label: string;
  method: string;
  status: 'pending' | 'processing' | 'completed';
}

export interface InspectionRecord {
  id: string;
  timestamp: string;
  metadata: SpoutMetadata;
  result: AnalysisResult;
}
